/** Automatically generated file. DO NOT MODIFY */
package com.symatech.echama;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}